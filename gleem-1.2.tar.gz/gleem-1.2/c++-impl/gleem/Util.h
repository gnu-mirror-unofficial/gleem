/*
 * gleem -- OpenGL Extremely Easy-To-Use Manipulators.
 * Copyright (C) 1998 Kenneth B. Russell (kbrussel@media.mit.edu)
 * See the file LICENSE.txt in the doc/ directory for licensing terms.
 */

#ifndef _GLEEM_UTIL_H
#define _GLEEM_UTIL_H

#define GLEEM_INTERNAL

#endif  // #defined _GLEEM_UTIL_H

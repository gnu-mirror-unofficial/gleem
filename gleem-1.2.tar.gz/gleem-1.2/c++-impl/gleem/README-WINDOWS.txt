To run the Windows demos, you first need either to add the location of
gleem-1.1/lib/nt to your PATH (recommended) or copy gleem.dll into your
WINNT/SYSTEM32 directory (not recommended).

